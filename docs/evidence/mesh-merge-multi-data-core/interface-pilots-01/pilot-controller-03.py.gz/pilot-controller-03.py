from pathlib import Path
import json,subprocess,sys,time
root=Path.cwd();plan=Path('/private/tmp/formora-multi-merge-pilot-plan-01.json');out=Path('/private/tmp/formora-multi-merge-pilot-process-03');out.mkdir(exist_ok=False)
value=json.loads(plan.read_text());command=[sys.executable,str(root/'tools/multi_mesh_merge_runtime.py'),'--binary','/private/tmp/formora-multi-merge-target-actual185/debug/formora','--output','/private/tmp/formora-multi-merge-api-pilot-03',*[part for id in value['case_ids'] for part in ['--case',id]]]
with (out/'stdout').open('x') as stdout,(out/'stderr').open('x') as stderr:
 process=subprocess.Popen(command,stdout=stdout,stderr=stderr);(out/'started.json').write_text(json.dumps({'process_id':process.pid,'command':command,'cases':value['pilot_cases']},indent=2)+'\n');code=process.wait()
(out/'terminal.json').write_text(json.dumps({'process_id':process.pid,'terminal_exit_code':code},indent=2)+'\n');print(json.dumps({'terminal_exit_code':code,'process_id':process.pid}));raise SystemExit(code)
