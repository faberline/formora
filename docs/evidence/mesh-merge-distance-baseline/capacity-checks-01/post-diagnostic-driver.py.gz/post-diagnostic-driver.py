from datetime import datetime,timezone
import hashlib,json,subprocess,time
from pathlib import Path
ROOT=Path('/private/tmp/formora-merge-distance-baseline')
PYTHON='/Users/chrischeng/.pyenv/versions/3.12.11/bin/python3'
OUT=Path('/private/tmp/formora-distance-capacity-controller-02');OUT.mkdir(exist_ok=False)
native=Path('/private/tmp/formora-distance-capacity-diagnostic-02')
started=time.monotonic()
while not (native/'terminal.json').is_file():
 if time.monotonic()-started>5400:raise TimeoutError('required native terminal missing')
 time.sleep(5)
terminal=json.loads((native/'terminal.json').read_text())
assert terminal['terminal_exit_code']==0 and terminal['timed_out'] is False,'required native failed'
def run(name,args):
 folder=OUT/name;folder.mkdir();command=[PYTHON,*args]
 script=ROOT/args[0]
 with (folder/'stdout').open('x') as stdout,(folder/'stderr').open('x') as stderr:
  process=subprocess.Popen(command,cwd=ROOT,stdout=stdout,stderr=stderr)
  (folder/'started.json').write_text(json.dumps({'process_id':process.pid,'command_line':command,'script_sha256':hashlib.sha256(script.read_bytes()).hexdigest(),'started_utc':datetime.now(timezone.utc).isoformat()},indent=2)+'\n')
  before=time.monotonic();code=process.wait()
 result={'process_id':process.pid,'terminal_exit_code':code,'elapsed_seconds':time.monotonic()-before,'stdout_sha256':hashlib.sha256((folder/'stdout').read_bytes()).hexdigest(),'stderr_sha256':hashlib.sha256((folder/'stderr').read_bytes()).hexdigest()}
 (folder/'terminal.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'stage':name,**result}),flush=True)
 if code:raise SystemExit(code)
common=['--suite','baseline/fixtures/mesh-merge-distance-capacity-01.json','--capacity-seal','baseline/fixtures/mesh-merge-distance-capacity-seal-01.json']
cases=[f'distance_class_a_{i:03}' for i in [3,6,9,12,15,18,21]]
run('diagnostic-check',['tools/check_merge_distance_capacity_reference.py',*common,'--native',str(native),'--output','/private/tmp/formora-distance-capacity-diagnostic-check-02.json',*[x for name in cases for x in ['--case',name]]])
run('corruption-controls',['tools/check_merge_distance_capacity_controls.py',*common,'--native','/private/tmp/formora-distance-capacity-diagnostic-01','--output','/private/tmp/formora-distance-capacity-controls-01','--case','distance_class_a_000'])
(OUT/'complete.json').write_text(json.dumps({'required_stages_passed':True,'native_capacity_complete_gate':'unrun','rust_product_timing':'unrun'},indent=2)+'\n')
