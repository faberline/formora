import gzip,hashlib,json,sys
from pathlib import Path
ROOT=Path('/private/tmp/formora-merge-distance-baseline/docs/evidence/mesh-merge-distance-baseline')
def archive(source,name):
 source=Path(source);destination=ROOT/name;destination.mkdir(exist_ok=False)
 rows=[]
 for path in sorted(source.rglob('*')):
  if not path.is_file():continue
  relative=path.relative_to(source);raw=path.read_bytes()
  payload=raw if path.suffix=='.gz' else gzip.compress(raw,mtime=0)
  stored=destination/relative if path.suffix=='.gz' else destination/(str(relative)+'.gz')
  stored.parent.mkdir(parents=True,exist_ok=True)
  with stored.open('xb') as stream:stream.write(payload)
  assert stored.read_bytes()==payload and path.read_bytes()==raw
  if path.suffix!='.gz':assert gzip.decompress(payload)==raw
  rows.append({'original':relative.as_posix(),'stored':stored.relative_to(destination).as_posix(),'raw_sha256':hashlib.sha256(raw).hexdigest(),'stored_sha256':hashlib.sha256(payload).hexdigest(),'raw_bytes':len(raw)})
 result={'source':str(source),'lossless_copies_verified':True,'originals_preserved':True,'files':rows}
 (destination/'archive-manifest.json').write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps({'archive':name,'files':len(rows)}),flush=True)
if __name__=='__main__':archive(sys.argv[1],sys.argv[2])
