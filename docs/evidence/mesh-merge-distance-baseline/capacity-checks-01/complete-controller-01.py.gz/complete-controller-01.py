"""Run only admitted full source captures; retain every actual stage wait."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('/private/tmp/formora-merge-distance-baseline')
PYTHON = '/Users/chrischeng/.pyenv/versions/3.12.11/bin/python3'
OUT = Path('/private/tmp/formora-distance-capacity-complete-controller-01')
PREVIOUS = Path('/private/tmp/formora-distance-capacity-controller-02')
SUITE = ROOT/'baseline/fixtures/mesh-merge-distance-capacity-01.json'
SEAL = ROOT/'baseline/fixtures/mesh-merge-distance-capacity-seal-01.json'
sys.path.insert(0, str(ROOT/'tools'))
from merge_distance_capacity_seal import verify


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text())


def preflight():
    assert read(PREVIOUS/'complete.json')['required_stages_passed'] is True
    for name in ['diagnostic-check', 'corruption-controls']:
        folder = PREVIOUS/name
        started, terminal = read(folder/'started.json'), read(folder/'terminal.json')
        assert type(terminal['terminal_exit_code']) is int and terminal['terminal_exit_code'] == 0
        assert terminal['process_id'] == started['process_id'] > 0
        assert terminal['stdout_sha256'] == digest(folder/'stdout')
        assert terminal['stderr_sha256'] == digest(folder/'stderr')
        assert started['script_sha256'] == digest(ROOT/started['command_line'][1])
    reports = [read(Path('/private/tmp/formora-distance-capacity-diagnostic-check-01.json')),
               read(Path('/private/tmp/formora-distance-capacity-diagnostic-check-02.json'))]
    assert [report['cases'] for report in reports] == [1, 7]
    assert all(report['source_capture_checks_passed'] is True for report in reports)
    assert all(report['capacity_seal_sha256'] == digest(SEAL) for report in reports)
    controls = read(Path('/private/tmp/formora-distance-capacity-controls-01/report.json'))
    assert controls['genuine_capture_checks_passed'] is True
    assert controls['controls_rejected'] == len(controls['controls']) == 34
    assert all(row['rejected'] is True for row in controls['controls'])
    assert controls['forged_native_operations_executed'] is False
    assert controls['control_script_sha256'] == digest(ROOT/'tools/check_merge_distance_capacity_controls.py')
    assert controls['capacity_seal_sha256'] == digest(SEAL)
    seal = verify(SUITE, SEAL, True)
    return {'diagnostic_source_checks': [1, 7], 'rejected_capacity_controls': 34,
            'capacity_seal_sha256': digest(SEAL), 'hardware': seal['hardware'],
            'product_limits': seal['product_limits'], 'rust_product_timing': 'unrun'}


def stage(name, arguments):
    folder = OUT/name
    folder.mkdir(exist_ok=False)
    command = [PYTHON, *arguments]
    before = time.monotonic()
    with (folder/'stdout').open('x') as stdout, (folder/'stderr').open('x') as stderr:
        process = subprocess.Popen(command, cwd=ROOT, stdout=stdout, stderr=stderr)
        (folder/'started.json').write_text(json.dumps({
            'process_id': process.pid, 'command_line': command,
            'script_sha256': digest(ROOT/arguments[0]),
            'started_utc': datetime.now(timezone.utc).isoformat()}, indent=2)+'\n')
        code = process.wait()
    result = {'process_id': process.pid, 'terminal_exit_code': code,
              'elapsed_seconds': time.monotonic()-before,
              'stdout_sha256': digest(folder/'stdout'), 'stderr_sha256': digest(folder/'stderr')}
    (folder/'terminal.json').write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps({'stage': name, **result}), flush=True)
    if code:
        raise SystemExit(code)
    return result


if __name__ == '__main__':
    gates = preflight()
    destinations = [Path('/private/tmp/formora-distance-capacity-complete-'+number) for number in ['01', '02']]
    reports = [Path('/private/tmp/formora-distance-capacity-complete-check-'+number+'.json') for number in ['01', '02']]
    paired = Path('/private/tmp/formora-distance-capacity-complete-pair-01.json')
    assert not any(path.exists() for path in [*destinations, *reports, paired, OUT])
    OUT.mkdir(exist_ok=False)
    identity = {'controller_sha256': digest(Path(__file__)), 'preflight': gates,
                'git_head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
                'started_utc': datetime.now(timezone.utc).isoformat()}
    (OUT/'admission.json').write_text(json.dumps(identity, indent=2)+'\n')
    common = ['--suite', str(SUITE), '--capacity-seal', str(SEAL)]
    waits = []
    for number, destination, report in zip(['01', '02'], destinations, reports):
        waits.append(stage('native-'+number, ['tools/launch_merge_distance_capacity_reference.py',
            *common, '--output', str(destination), '--timeout', '43200']))
        waits.append(stage('check-'+number, ['tools/check_merge_distance_capacity_reference.py',
            *common, '--native', str(destination), '--output', str(report)]))
        checked = read(report)
        assert checked['source_capture_checks_passed'] is True and checked['cases'] == 192
    waits.append(stage('pair', ['tools/compare_merge_distance_capacity_reference.py', *common,
        '--first', str(destinations[0]), '--second', str(destinations[1]), '--output', str(paired)]))
    result = read(paired)
    assert result['both_complete_capacity_sources_passed'] is True
    assert result['samples_per_capture'] == 192 and result['forms'] == 64 and result['samples_per_form'] == 3
    assert digest(Path(__file__)) == identity['controller_sha256']
    (OUT/'complete.json').write_text(json.dumps({
        'required_source_stages_passed': True, 'waits': waits,
        'paired_report_sha256': digest(paired), 'samples_per_capture': 192,
        'source_over_budget_samples_per_capture': result['source_over_budget_samples_per_capture'],
        'rust_product_timing': 'unrun', 'product_acceptance': 'unrun'}, indent=2)+'\n')
